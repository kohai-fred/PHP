<?php

require_once 'inc/init.php';

require_once 'inc/header.php';
?>
<div class="container my-4">
    <img src="src_photo/vente-immobiliere-2.jpg" alt="">
</div>
<?php
require_once 'inc/footer.php';